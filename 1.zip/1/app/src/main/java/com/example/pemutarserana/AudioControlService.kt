package com.example.pemutarserana

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AudioControlService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private lateinit var kontrolRef: DatabaseReference
    private var firebaseListener: ValueEventListener? = null

    private val CHANNEL_ID = "SeranaRemoteChannel"
    private val NOTIFICATION_ID = 101

    override fun onCreate() {
        super.onCreate()
        buatNotificationChannel()
        startForeground(NOTIFICATION_ID, buatNotifikasi("Menghubungkan ke Firebase..."))

        // Inisialisasi Firebase secara manual menggunakan data dari Web App Config Anda
        val firebaseApp = inisialisasiFirebaseManual()

        val database = FirebaseDatabase.getInstance(
            firebaseApp,
            "https://firebasedatabase.app"
        )
        kontrolRef = database.getReference("putar_audio")

        mulaiPantauFirebase()
    }

    private fun inisialisasiFirebaseManual(): FirebaseApp {
        // Cek apakah instance "SeranaApp" sudah pernah dibuat agar tidak error saat service restart
        val existingApp = FirebaseApp.getApps(this).find { it.name == "SeranaApp" }
        if (existingApp != null) {
            return existingApp
        }

        val options = FirebaseOptions.Builder()
            .setApiKey("AIzaSyBHBDWCn5dR5B4DQCEC1-PY-Zv1L_LLbYA")
            .setApplicationId("1:342881381128:web:f53a653eb91f830ecd9abd")
            .setDatabaseUrl("https://firebasedatabase.app")
            .setProjectId("control-91ff1")
            .setStorageBucket("control-91ff1.firebasestorage.app")
            .build()

        return FirebaseApp.initializeApp(this, options, "SeranaApp")
    }

    private fun mulaiPantauFirebase() {
        firebaseListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val perintahPutar = snapshot.getValue(Boolean::class.java) ?: false

                if (perintahPutar) {
                    perbaruiNotifikasi("Sedang memutar serana.mp3 🎵")
                    putarAudio()
                } else {
                    perbaruiNotifikasi("Standby: Menunggu perintah ⏸")
                    hentikanAudio()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                perbaruiNotifikasi("Error Firebase: ${error.message}")
            }
        }
        kontrolRef.addValueEventListener(firebaseListener!!)
    }

    private fun putarAudio() {
        if (mediaPlayer?.isPlaying == true) return

        mediaPlayer = MediaPlayer.create(this, R.raw.serana).apply {
            setOnCompletionListener {
                kontrolRef.setValue(false)
            }
            start()
        }
    }

    private fun hentikanAudio() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
    }

    private fun buatNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Layanan Kontrol Audio",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buatNotifikasi(teksStatus: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Remote Audio Serana Aktif")
            .setContentText(teksStatus)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun perbaruiNotifikasi(teksStatus: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buatNotifikasi(teksStatus))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        firebaseListener?.let { kontrolRef.removeEventListener(it) }
        hentikanAudio()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
