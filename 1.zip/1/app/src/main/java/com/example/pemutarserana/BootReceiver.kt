package com.example.pemutarserana

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AudioControlService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private lateinit var kontrolRef: DatabaseReference
    private var firebaseListener: ValueEventListener? = null

    private val CHANNEL_ID = "SeranaRemoteChannel"
    private val NOTIFICATION_ID = 101

    override fun onCreate() {
        super.onCreate()
        buatNotificationChannel()
        startForeground(NOTIFICATION_ID, buatNotifikasi("Menunggu perintah remote HTML..."))

        val database = FirebaseDatabase.getInstance(
            "https://firebasedatabase.app"
        )
        kontrolRef = database.getReference("putar_audio")

        mulaiPantauFirebase()
    }

    private fun mulaiPantauFirebase() {
        firebaseListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val perintahPutar = snapshot.getValue(Boolean::class.java) ?: false

                if (perintahPutar) {
                    perbaruiNotifikasi("Sedang memutar serana.mp3 🎵")
                    putarAudio()
                } else {
                    perbaruiNotifikasi("Standby: Menunggu perintah ⏸")
                    hentikanAudio()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                perbaruiNotifikasi("Koneksi Firebase terputus")
            }
        }
        kontrolRef.addValueEventListener(firebaseListener!!)
    }

    private fun putarAudio() {
        if (mediaPlayer?.isPlaying == true) return

        mediaPlayer = MediaPlayer.create(this, R.raw.serana).apply {
            setOnCompletionListener {
                kontrolRef.setValue(false)
            }
            start()
        }
    }

    private fun hentikanAudio() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
    }

    private fun buatNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Layanan Kontrol Audio",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buatNotifikasi(teksStatus: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Remote Audio Serana Aktif")
            .setContentText(teksStatus)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun perbaruiNotifikasi(teksStatus: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buatNotifikasi(teksStatus))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        firebaseListener?.let { kontrolRef.removeEventListener(it) }
        hentikanAudio()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
