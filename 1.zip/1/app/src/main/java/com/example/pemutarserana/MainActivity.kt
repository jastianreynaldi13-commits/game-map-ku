package com.example.pemutarserana

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var infoText: TextView

    private val requestNotifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            mulaiServiceLatarBelakang()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 50, 50, 50)
        }

        infoText = TextView(this).apply {
            text = "Service latar belakang aktif.\nAplikasi boleh ditutup, audio tetap akan merespons remote HTML."
            textSize = 16f
            setPadding(0, 0, 0, 30)
        }

        val btnMulaiService = Button(this).apply {
            text = "Aktifkan Service Latar Belakang"
            setOnClickListener {
                cekIzinDanMulaiService()
                infoText.text = "Service latar belakang aktif.\nMenunggu sinyal dari remote HTML..."
            }
        }

        val btnMatikanService = Button(this).apply {
            text = "Matikan Service Sepenuhnya"
            setOnClickListener {
                stopService(Intent(this@MainActivity, AudioControlService::class.java))
                infoText.text = "Service dimatikan. Klik 'Aktifkan' untuk menyalakan kembali."
            }
        }

        layout.addView(infoText)
        layout.addView(btnMulaiService)
        layout.addView(btnMatikanService)
        setContentView(layout)

        cekIzinDanMulaiService()
    }

    private fun cekIzinDanMulaiService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                mulaiServiceLatarBelakang()
            } else {
                requestNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            mulaiServiceLatarBelakang()
        }
    }

    private fun mulaiServiceLatarBelakang() {
        val intent = Intent(this, AudioControlService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
